# TMDB Movie Analytics Project

## Project Overview
Analyze TMDB movie data to understand ratings,
popularity, budget, revenue, and genres.

## Tools Used
- Python
- Pandas
- Matplotlib
- Seaborn
- SQL
- Streamlit

## Analysis
- Top-rated and popular movies
- Budget, revenue, profit, and ROI
- Genre-wise popularity
- Movies released per year
- Runtime distribution
- Correlation analysis

## Dashboard
An interactive Streamlit dashboard is included.

## Conclusion
This project uses data analysis and visualization
to explore movie trends and performance.
